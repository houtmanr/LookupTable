#include <afxdb.h>
#include "Sclass.h"

class DBase
{
public:
  DBase();
  ~DBase(void);
};